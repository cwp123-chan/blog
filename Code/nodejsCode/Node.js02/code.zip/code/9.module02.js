
var user = require('./module/user.js');

var jingjing = new user('静静', 19);

console.log(jingjing);

console.log(jingjing.name);
console.log(jingjing.age);
jingjing.getInfo();

