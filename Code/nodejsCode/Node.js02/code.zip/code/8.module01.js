
var fun1 = require('./module/fun1.js');


console.log(fun1.str);
fun1.showMsg();



